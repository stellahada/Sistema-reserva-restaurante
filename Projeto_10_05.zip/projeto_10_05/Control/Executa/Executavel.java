package Executa;

import TelaBase.TelaLogin;
import TelasAdm.RelatorioReservas;
import TelasAdm.TelaCadastroADM;
import TelasAdm.TelaLoginADM;
import TelasAdm.TelaMenuAdm;
import TelasCliente.TelaCadastroCliente;
import TelasCliente.TelaLoginCliente;

public class Executavel {
public static void main(String[] args) {
		new TelaLogin(false);
		new TelaMenuAdm(false);
		new RelatorioReservas(true);
		new TelaCadastroCliente(false);
		new TelaLoginCliente(false);
		new TelaLoginADM(false);
		new TelaCadastroADM(true);
}
}
 