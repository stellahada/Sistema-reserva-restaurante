package Geral;
import Supers.Consumivel;

public class Bebida extends Consumivel {
private boolean alcoolico;

public Bebida() {
	
}

public Bebida(String nome,double preco,String regiao,String descricao,boolean alcoolocio) {
	
}

public boolean isAlcoolico() {
	return alcoolico;
}

public void setAlcoolico(boolean alcoolico) {
	this.alcoolico = alcoolico;
}

}
