package Classe;
import java.net.*;

import javax.swing.ImageIcon;

public class ImagensFeitas {
	
	public ImageIcon imagem(String nome) throws MalformedURLException{
		if(nome.equalsIgnoreCase("KAKA")) {
			URL urlImg = new URL("https://live.staticflickr.com/65535/53723362830_e1bf8457bc_m.jpg");
			ImageIcon rImagem = new ImageIcon(urlImg);
			return rImagem;	
		}
		if(nome.equalsIgnoreCase("Estrela")) {
			URL urlImg = new URL("https://cdn-icons-png.flaticon.com/512/541/541415.png");
			ImageIcon rImagem = new ImageIcon(urlImg);
			return rImagem;	
		}
		if(nome.equalsIgnoreCase("Logo")) {
			URL urlImg = new URL("https://cdn-icons-png.flaticon.com/512/242/242452.png");
			ImageIcon rImagem = new ImageIcon(urlImg);
			return rImagem;	
		}
		return null;
	}
}
