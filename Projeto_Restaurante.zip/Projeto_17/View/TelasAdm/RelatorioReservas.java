package TelasAdm;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.net.MalformedURLException;
import java.net.URL;

public class RelatorioReservas {

	private static Point mouseDownCompCoords;
	int distancia=70;
	JFrame frame = new JFrame();
	Boolean apertou = false;
	JButton maximo = new JButton("□");
	JButton fecha = new JButton("X");
	JButton minimo = new JButton("━");
	JPanel painelMeio = new JPanel();
	JButton pesquisar = new JButton();
	ImageIcon imagem = new ImageIcon("C:\\eclipse\\eclipse\\eclipse\\Projteo\\View\\Imagens\\Pesquisar.png");
	ImageIcon imagemHover = new ImageIcon("C:\\eclipse\\eclipse\\eclipse\\Projteo\\View\\Imagens\\pesquisarHover.png");
	JTextField nPesquisar = new JTextField() {        
		
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics2D = (Graphics2D) g.create();
            int width = getWidth();
            int height = getHeight();
            int cornerRadius = 10;
            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, cornerRadius,cornerRadius);
            graphics2D.setColor(getBackground());
            graphics2D.setColor(getForeground());
            graphics2D.setStroke(new BasicStroke(5));
            graphics2D.draw(roundedRectangle);
            graphics2D.dispose();
            
          
        }
        
	};
	JPanel painelReservas = new JPanel(new BorderLayout()) {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics2D = (Graphics2D) g.create();
            int width = getWidth();
            int height = getHeight();
            int cornerRadius = 100;
            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, cornerRadius,cornerRadius);
            graphics2D.setColor(getBackground());
            graphics2D.setStroke(new BasicStroke(5));
            graphics2D.fill(roundedRectangle);
            graphics2D.setColor(getForeground());
            graphics2D.draw(roundedRectangle);
            graphics2D.dispose();
        }
        
    };
    int alturaP=30;
    int tamanhoP=600;
    JPanel painelReservasUnitario = new JPanel(){        
		
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics2D = (Graphics2D) g.create();
            int width = getWidth();
            int height = getHeight();
            int cornerRadius = 30;
            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, cornerRadius,cornerRadius);
            graphics2D.setColor(getBackground());
            graphics2D.setColor(getForeground());
            graphics2D.setStroke(new BasicStroke(5));
            graphics2D.draw(roundedRectangle);
            graphics2D.dispose();
            
          
        }
        
	};

	JLabel tituloL = new JLabel();
	
	JPanel titulo = new JPanel(){        
		
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics2D = (Graphics2D) g.create();
            int width = getWidth();
            int height = getHeight();
            int cornerRadius = 10;
            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, cornerRadius,cornerRadius);
            graphics2D.setColor(getBackground());
            graphics2D.setColor(getForeground());
            graphics2D.setStroke(new BasicStroke(5));
            graphics2D.draw(roundedRectangle);
            graphics2D.dispose();
            
          
        }
        
	};
	JPanel novaBarra = new JPanel(new BorderLayout()) {
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.black);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.WHITE);
			g.drawString("Relatorio de Reservas", getWidth() / 2 - 50, 25);
		}
	};
	public RelatorioReservas() {
		
	}

	public RelatorioReservas(boolean ligaTela) {
		// Remove a barra de titulo padrao
		frame.setUndecorated(true);
		// Define o tamanho
		frame.setSize(1000, 600);
		// Centraliza
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);
		// Cria um barra de titulo nova
		// define o tamanho da barra com a largura no tamanho da tela e a altura em 30
		novaBarra.setBounds(0, 0, frame.getWidth(), 40);

		// cria um painel para juntar os botoes
		JPanel botoes = new JPanel();
		// Define o tamanho do painel
		botoes.setSize(300, 30);
		// Define a cor
		botoes.setBackground(Color.black);
		// Adiciona os botoes ao painel
		botoes.add(minimo);
		botoes.add(maximo);
		botoes.add(fecha);
		// adiciona o painel de botoes na barra de titulo
		novaBarra.add(botoes, BorderLayout.EAST);

		// Adiciona um evento para quando clicar o mouse na tela, pegar as coordenadas
		frame.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				mouseDownCompCoords = e.getPoint();
			}
		});
		// Adiciona um evento para quando clicar o mouse na tela e arrastar pegar as coordenadas e subtrair com a antiga parada
		frame.addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent e) {
				Point currCoords = e.getLocationOnScreen();
				frame.setLocation(currCoords.x - mouseDownCompCoords.x, currCoords.y - mouseDownCompCoords.y);
			}
		});
		
		// Adiciona a barra de titulo na tela
		frame.getContentPane().add(novaBarra);
		
		
		//Daqui para baixo é o codigo que vai no centro da tela

		// Define o tamanho do painel
		painelMeio.setBounds(0, 40, frame.getWidth(), frame.getHeight());
		painelMeio.setLayout(null);
		// Define a cor
		painelMeio.setBackground(Color.black);
		//Botao X para fechar a tela
		criaBotao("fecha",fecha, 0, 0, 0, 0, Color.black, Color.white,fecha.getFont().deriveFont(Font.BOLD, 14));
		//Botao que maximiza a tela
		criaBotao("maximo",maximo, 0, 0, 0, 0, Color.black, Color.white,maximo.getFont().deriveFont(Font.BOLD, 14));
		//Botao que minimiza a tela
		criaBotao("minimo",minimo, 0, 0, 0, 0, Color.black, Color.white,minimo.getFont().deriveFont(Font.BOLD, 14));
		
		
		titulo.setBounds(painelMeio.getWidth()/2-190,painelMeio.getWidth()/2-450,400,30);
		titulo.setBackground(new Color(255, 180, 91));
		titulo.setForeground(Color.black);
		tituloL.setText("Relatorio de Reservas");
		
		titulo.add(tituloL);
	
		
		
		
		
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		adicionaReserva("Erick Duarte Bernat", "08/05/2024", "Mani", "200,00", distancia);
		
		
		painelReservas.setBounds(painelMeio.getWidth()/2-360, painelMeio.getHeight()/2-200, 750, 400);
		painelReservas.setBackground(Color.black);
		painelReservas.setForeground(Color.white);
		painelReservas.setLayout(null);

		
		criaBotao("pesquisa",pesquisar,painelReservas.getWidth()/2+190,painelReservas.getHeight()/2-185, 30, 40, Color.black, Color.white,pesquisar.getFont().deriveFont(Font.BOLD, 14));
		pesquisar.setLayout(null);
		pesquisar.setIcon(imagem);
		pesquisar.addMouseListener(eventoMouse(pesquisar));
		
		nPesquisar.setBounds(painelReservas.getWidth() / 2-210, painelReservas.getHeight() / 2-180 , 400, 30);
		nPesquisar.setBackground(Color.gray);
		nPesquisar.setBorder(null);
		nPesquisar.setText("Digite uma data para pesquisar por reservas");
		nPesquisar.setForeground(Color.black);
		nPesquisar.setHorizontalAlignment(0);
		nPesquisar.setName("Texto");
		nPesquisar.addMouseListener(eventoMouseField(nPesquisar));
		
		painelReservas.add(pesquisar);
		painelReservas.add(nPesquisar);
		painelReservas.add(painelReservasUnitario);
		painelMeio.add(titulo);
		painelMeio.add(painelReservas);
		
		
		// Chama a funcao para fechar a tela
		fecha.addActionListener(e -> frame.dispose());
		// Chama a funçao para evento de maximizar a tela
		maximo.addActionListener(this::maximiza);
		// Chama a funçao para evento de minimizar a tela
		minimo.addActionListener(e -> frame.setState(JFrame.ICONIFIED));
		//adiciona o metodo de hover nos botoes do barra de titulo e da nome a eles
				fecha.addMouseListener(eventoMouse(fecha));
				maximo.addMouseListener(eventoMouse(maximo));
				minimo.addMouseListener(eventoMouse(minimo));
		//adiciona o painel preto na tela
		frame.getContentPane().add(painelMeio);

		frame.setVisible(ligaTela);
	}

	// Metodo para maximizar a tela e desmaximizar
	public void maximiza(ActionEvent actionEvent) {
		if (apertou == false) {
			frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			painelMeio.setBounds(0, 40, frame.getWidth(), frame.getHeight());
			titulo.setBounds(painelMeio.getWidth()/2-190,painelMeio.getWidth()/2-820,400,30);
			novaBarra.setBounds(0, 0, frame.getWidth(), 40);
			painelReservas.setBounds(painelMeio.getWidth()/2-490, painelMeio.getHeight()/2-330, 1000, 650);
			nPesquisar.setBounds(painelReservas.getWidth() / 2-210, painelReservas.getHeight() / 2-300 , 400, 30);
			criaBotao("pesquisa",pesquisar,painelReservas.getWidth()/2+190,painelReservas.getHeight()/2-305, 30, 40, Color.black, Color.white,pesquisar.getFont().deriveFont(Font.BOLD, 14));
			maximo.setText("❐");
			apertou = true;
			
		} else {
			frame.setSize(1000, 600);
			frame.setLocationRelativeTo(null);
			painelMeio.setBounds(0, 40, frame.getWidth(), frame.getHeight());
			titulo.setBounds(painelMeio.getWidth()/2-190,painelMeio.getWidth()/2-450,400,30);
			novaBarra.setBounds(0, 0, frame.getWidth(), 40);
			painelReservas.setBounds(painelMeio.getWidth()/2-360, painelMeio.getHeight()/2-200, 750, 400);
			nPesquisar.setBounds(painelReservas.getWidth() / 2-210, painelReservas.getHeight() / 2-180 , 400, 30);
			maximo.setText("□");
			apertou = false;
		}
	}
	//Metodo Cria botao
	public void criaBotao(String nome,JButton botao,int x, int y, int largura, int altura,Color corB,Color corF,Font fonte) {
		botao.setName(nome);
		botao.setBounds(x, y, largura, altura);
		botao.setBackground(corB);
		botao.setForeground(corF);
		botao.setFocusPainted(false);
		botao.setBorderPainted(false);
		botao.setFont(fonte);
		
	}
	//Metodo adiciona evento de mouse botoes
	public MouseAdapter eventoMouse(JButton botao) {
		MouseAdapter evento = null;
		if(botao.getName().equalsIgnoreCase("fecha") || botao.getName().equalsIgnoreCase("maximo") || botao.getName().equalsIgnoreCase("minimo")){
			evento = new java.awt.event.MouseAdapter() {
				 public void mouseEntered(java.awt.event.MouseEvent evt) {
				        botao.setBackground(Color.red);
				    }
				    public void mouseExited(java.awt.event.MouseEvent evt) {
				        botao.setBackground(Color.black);
				    }};
		}
		return evento;
	}
	public void adicionaReserva(String nomer,String datar,String restauranter, String valorr,int distancia) {
		JPanel painel = new JPanel(){        
			
	        @Override
	        protected void paintComponent(Graphics g) {
	            super.paintComponent(g);
	            Graphics2D graphics2D = (Graphics2D) g.create();
	            int width = getWidth();
	            int height = getHeight();
	            int cornerRadius = 30;
	            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, cornerRadius,cornerRadius);
	            graphics2D.setColor(getBackground());
	            graphics2D.setColor(getForeground());
	            graphics2D.setStroke(new BasicStroke(5));
	            graphics2D.draw(roundedRectangle);
	            graphics2D.dispose();
	            
	          
	        }
	        
		};
		JLabel data = new JLabel();
		JLabel cliente = new JLabel();
		JLabel restaurante = new JLabel();
		JLabel valor = new JLabel();
		painel.setBounds(painelReservas.getWidth()/2+80, painelReservas.getHeight()/2+distancia, tamanhoP, alturaP);
		this.distancia+=40;
		painel.setBackground(Color.black);
		painel.setForeground(Color.white);
		painel.setLayout(null);
		data.setText(datar);
		data.setForeground(Color.white);
		data.setBounds(20, -25, 80, 80);
		cliente.setText(nomer);
		cliente.setForeground(Color.white);
		cliente.setBounds(160, -25, 200, 80);
		restaurante.setText(restauranter);
		restaurante.setForeground(Color.white);
		restaurante.setBounds(350, -25, 80, 80);
		valor.setText("R$"+valorr);
		valor.setForeground(Color.white);
		valor.setBounds(500, -25, 80, 80);
		painel.add(data);
		painel.add(cliente);
		painel.add(restaurante);
		painel.add(valor);
		painelReservas.add(painel);
	}
	public MouseAdapter eventoMouseField(JTextField j) {
		MouseAdapter evento = null;
		if(j.getName().equalsIgnoreCase("Texto")){
			evento = new java.awt.event.MouseAdapter() {
				 public void mouseClicked(java.awt.event.MouseEvent evt) {
				       j.setText("");
				    }
				    };
		}
		return evento;
	}
}