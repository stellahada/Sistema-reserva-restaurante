package Executa;

import java.awt.Component;
import java.net.MalformedURLException;

import javax.swing.JFrame;

import TelaBase.TelaLogin;
import TelasAdm.RelatorioReservas;
import TelasAdm.TelaCadastroADM;
import TelasAdm.TelaLoginADM;
import TelasAdm.TelaMenuAdm;
import TelasCliente.TelaCadastroCliente;
import TelasCliente.TelaLoginCliente;

public class Executavel extends JFrame{
		// Cria um barra de titulo nova	}
public static void main(String[] args) throws MalformedURLException {
		new TelaLogin(true);
		new TelaMenuAdm(false);
		new RelatorioReservas(false);
		new TelaCadastroCliente(false);
		new TelaLoginCliente(false);
		new TelaLoginADM(false,"max");
		new TelaCadastroADM(false);
}
}
 